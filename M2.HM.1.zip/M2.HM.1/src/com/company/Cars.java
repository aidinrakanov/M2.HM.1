package com.company;

public class Cars extends Transport {

    private String madeIN;
    private int transmission;

    public Cars(int year, int mileage, Model model, Colour colour, String madeIN, int transmission) {
        super(year, mileage, model, colour);
        this.madeIN = madeIN;
        this.transmission = transmission;
    }

    public String getMadeIN() {
        return madeIN;
    }

    public int getTransmission() {
        return transmission;
    }

}
