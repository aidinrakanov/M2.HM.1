package com.company;

public enum Colour { BLACK, WHITE, BLUE, SILVER
}
