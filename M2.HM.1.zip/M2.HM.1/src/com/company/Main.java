package com.company;

public class Main {

    public static void main(String[] args) {

        Sedan s1= new Sedan(25000,3.5, Colour.WHITE);



    }
}
