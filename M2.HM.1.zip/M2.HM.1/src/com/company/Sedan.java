package com.company;

public final class Sedan extends Cars {

    private int price;
    private Double volume;


    public Double getVolume() {
        return volume;
    }

    public Sedan(){}

    public Sedan(int price, Double volume, Colour colour) {
        this.price = price;
        this.volume = volume;
    }
}


