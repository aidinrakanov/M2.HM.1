package com.company;

import java.util.Random;

public class Transport {

    private int year;
    private int mileage;
    private Model model;
    private Colour colour;

    private int Mileage() {
        Random r = new Random();
        return r.nextInt(100000);
    }

    public int getYear() {
        return year;
    }

    public int getMileage() {
        return mileage;
    }



    public Model getModel() {
        return model;
    }

    public Colour getColour() {
        return colour;
    }
    public Transport(int year, int mileage, Model model, Colour colour) {
        this.year = year;
        this.mileage = mileage;
        this.model = model;
        this.colour = colour;
    }
}

